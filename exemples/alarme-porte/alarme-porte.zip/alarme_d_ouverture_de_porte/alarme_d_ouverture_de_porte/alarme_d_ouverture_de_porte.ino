// Alarme d'ouverture de porte — généré par MicroForge
// Un aimant sur la porte, un contact sur le cadre — la sirène retentit si quelqu'un ouvre.
// Carte : ESP32 DevKit V1 (ESP32-WROOM-32, 30 broches)
#include "mf_components.h"

void setup() {
  Serial.begin(115200);
  mf_setup_components();

}

void loop() {
  if (porte_open()) {
    voyant_on();
    sirene_beep(2200, 150);
    delay(300);
  } else {
    voyant_off();
    delay(50);
  }
}
