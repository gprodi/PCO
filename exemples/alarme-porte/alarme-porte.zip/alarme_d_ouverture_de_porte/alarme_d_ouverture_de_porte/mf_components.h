// mf_components.h — généré par MicroForge pour « Alarme d'ouverture de porte »
// Carte : ESP32 DevKit V1 (ESP32-WROOM-32, 30 broches) — FQBN esp32:esp32:esp32
// Ne modifiez pas ce fichier à la main : régénérez-le depuis MicroForge.
// À inclure UNIQUEMENT depuis le .ino (les fonctions y sont définies).
#pragma once
#include <Arduino.h>

#if defined(ESP32)
  #define MF_ADC_MAX 4095
#else
  #define MF_ADC_MAX 1023
#endif

// ---- Broches (cf. tableau de câblage) ----
const uint8_t PIN_PORTE_1 = 25;  // D25 -> porte.1
const uint8_t PIN_SIRENE_SIG = 26;  // D26 -> sirene.SIG
const uint8_t PIN_VOYANT_A = 27;  // D27 -> voyant.A

// ---- Objets des composants ----

// ---- Fonctions des composants (utilisables dans loop()) ----
// --- porte : Contact magnétique de porte (interrupteur à lame souple)
// Vrai quand l'aimant est éloigné (porte ouverte).
bool porte_open() { return digitalRead(PIN_PORTE_1) == HIGH; }
// --- sirene : Buzzer piézo passif
void sirene_beep(unsigned int freq, unsigned long ms) { tone(PIN_SIRENE_SIG, freq, ms); }
void sirene_stop() { noTone(PIN_SIRENE_SIG); }
// --- voyant : LED 5 mm
void voyant_on() { digitalWrite(PIN_VOYANT_A, HIGH); }
void voyant_off() { digitalWrite(PIN_VOYANT_A, LOW); }
void voyant_set(bool on) { digitalWrite(PIN_VOYANT_A, on ? HIGH : LOW); }
void voyant_toggle() { digitalWrite(PIN_VOYANT_A, !digitalRead(PIN_VOYANT_A)); }

// ---- Initialisation de tous les composants ----
inline void mf_setup_components() {
  // porte
  pinMode(PIN_PORTE_1, INPUT_PULLUP);
  // sirene
  pinMode(PIN_SIRENE_SIG, OUTPUT);
  // voyant
  pinMode(PIN_VOYANT_A, OUTPUT);
}
