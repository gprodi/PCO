## Câblage — Alarme d'ouverture de porte

Carte : **ESP32 DevKit V1 (ESP32-WROOM-32, 30 broches)** (logique 3.3 V). Couleurs conseillées : rouge = 5 V, orange = 3,3 V, noir = masse, bleu = SDA, jaune = SCL, violet = SPI, vert = signal.

| # | Composant | Broche composant | Broche carte | Rôle | Fil | Remarque |
|---|---|---|---|---|---|---|
| 1 | porte (Contact magnétique de porte (interrupteur à lame souple)) | 2 | GND | masse | noir |  |
| 2 | sirene (Buzzer piézo passif) | GND | GND | masse | noir |  |
| 3 | voyant (LED 5 mm) | C | GND | masse | noir |  |
| 4 | porte (Contact magnétique de porte (interrupteur à lame souple)) | 1 | D25 | entrée numérique | vert |  |
| 5 | sirene (Buzzer piézo passif) | SIG | D26 | sortie numérique | vert |  |
| 6 | voyant (LED 5 mm) | A | D27 | sortie numérique | vert | via résistance 150 Ω en série. |

### Composants ajoutés automatiquement

- `r_voyant_a` : 150 Ω — limite le courant de « voyant » (broche A) à ~10 mA en 3.3 V
