# Alarme d'ouverture de porte

Un aimant sur la porte, un contact sur le cadre — la sirène retentit si quelqu'un ouvre.

- Carte : **ESP32 DevKit V1 (ESP32-WROOM-32, 30 broches)** (`esp32:esp32:esp32`)
- Contrôle électrique : ✅ aucun problème bloquant

## Contenu
| Fichier | Rôle |
|---|---|
| `alarme_d_ouverture_de_porte/alarme_d_ouverture_de_porte.ino` | programme principal (logique modifiable) |
| `alarme_d_ouverture_de_porte/mf_components.h` | broches, objets et fonctions des composants |
| `cablage.md` / `cablage.svg` | tableau et schéma de câblage |
| `guide-montage.md` | guide pas-à-pas breadboard -> soudure -> contrôles |
| `wokwi/` | simulation : créer un projet sur wokwi.com et y coller ces fichiers |
| `kicad/projet.net` | netlist à importer dans l'éditeur de PCB KiCad |
| `nomenclature.csv` | liste du matériel |
| `platformio.ini` | compilation avec PlatformIO |

## Compiler et téléverser (arduino-cli)
```bash
arduino-cli lib install 
arduino-cli compile --fqbn esp32:esp32:esp32 alarme_d_ouverture_de_porte
arduino-cli upload --fqbn esp32:esp32:esp32 -p <PORT> alarme_d_ouverture_de_porte
```

## Contrôle électrique
- **INFO** `AUTO_SERIES` — Ajout automatique : 150 Ω (limite le courant de « voyant » (broche A) à ~10 mA en 3.3 V).

## Niveau de vérification
- ✅ Allocation des broches et contrôle électrique (ERC) : automatiques, à chaque génération.
- ✅ Syntaxe C++ : vérifiée par les tests du dépôt (g++ avec en-têtes Arduino simulés).
- ✅ Compilation réelle (arduino-cli, cœurs AVR / ESP32 / RP2040) : job « firmware » de la CI GitHub.
- ⚠️ Pas encore monté sur du vrai matériel : teste d'abord sur breadboard (ou dans Wokwi).

## Tutoriels équivalents (pour recouper câblage et code)
- [Arduino - Door Sensor - Piezo Buzzer](https://arduinogetstarted.com/tutorials/arduino-door-sensor-piezo-buzzer) — ArduinoGetStarted
- [Monitor your door using a magnetic reed switch and Arduino](https://randomnerdtutorials.com/monitor-your-door-using-magnetic-reed-switch-and-arduino/) — Random Nerd Tutorials

---
*Généré automatiquement par MicroForge (logique et textes pouvant provenir d'une IA — transparence AI Act art. 50). Vérifiez toujours le câblage avant la mise sous tension.*
