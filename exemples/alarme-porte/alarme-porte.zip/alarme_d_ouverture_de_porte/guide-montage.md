# Guide de montage — Alarme d'ouverture de porte

Un aimant sur la porte, un contact sur le cadre — la sirène retentit si quelqu'un ouvre.

## 1. Outillage

- Fer à souder thermostaté (300–350 °C), panne fine conique ou biseautée
- Étain 0,8 mm avec flux (sans plomb de préférence), éponge laiton
- Tresse ou pompe à dessouder, pince coupante, pince à dénuder
- Multimètre (continuité, tension), support « troisième main »
- Lunettes de protection, pièce aérée (fumées de flux)

## 2. Sécurité

- Toujours débrancher l'USB et les piles avant de souder ou de recâbler.
- Le fer chauffe à plus de 300 °C : le reposer sur son support, jamais sur la table.
- Se laver les mains après la soudure (étain/flux).

## 4. Étape 1 — Prototype sur breadboard (sans soudure)

1. Placer la carte à cheval sur la rainure centrale de la breadboard.
2. Relier les rails :  et **GND** (fil noir) aux lignes d'alimentation de la plaque.
3. Câbler en suivant le **tableau de câblage** (`cablage.md`) ligne par ligne, dans l'ordre : masse, alimentations, bus, signaux.
4. Insérer les résistances ajoutées automatiquement :
   - `r_voyant_a` 150 Ω — limite le courant de « voyant » (broche A) à ~10 mA en 3.3 V
5. Téléverser le firmware et valider le fonctionnement (moniteur série 115200 bauds) **avant** de souder quoi que ce soit.

## 5. Étape 2 — Montage définitif sur plaque à pastilles

1. Souder des **barrettes femelles** pour la carte (elle reste amovible) et des barrettes mâles/femelles pour chaque module.
2. Tracer les **rails d'alimentation** au fil rigide (rouge/orange) et la **masse** (noir) le long de la plaque.
3. Souder les **bus partagés** (I2C/SPI) en étoile depuis la carte.
4. Souder les **signaux** un par un en cochant le tableau de câblage.
5. Souder les **résistances** au plus près de la broche protégée.

### Geste de soudure

1. Chauffer **en même temps** la pastille et la patte (1–2 s).
2. Apporter l'étain sur la jonction (pas sur la panne).
3. Retirer l'étain puis le fer ; ne pas bouger pendant 2 s.
4. Contrôler : soudure brillante en forme de petit volcan, aucun pont avec la pastille voisine.

## 6. Contrôles au multimètre AVANT la mise sous tension

Mode continuité (bip). Chaque ligne doit biper entre toutes ses broches :

- [ ] **GND** : board.GND, porte.2, sirene.GND, voyant.C
- [ ] **PORTE_1** : board.D25, porte.1
- [ ] **SIRENE_SIG** : board.D26, sirene.SIG
- [ ] **VOYANT_A** : board.D27, r_voyant_a.1
- [ ] **VOYANT_A_R** : r_voyant_a.2, voyant.A

Puis, en mode ohmmètre, **aucun court-circuit** :

## 7. Première mise sous tension

1. Brancher l'USB seul (pas de piles) ; toucher les composants après 10 s : rien ne doit chauffer.
2. Téléverser `le sketch` (carte **ESP32 DevKit V1 (ESP32-WROOM-32, 30 broches)**, FQBN `esp32:esp32:esp32`).
3. Ouvrir le moniteur série (115200 bauds) et vérifier les messages d'initialisation.

## 8. Dépannage

- Vérifier masse commune et alimentation.
- Rien ne marche : vérifier la **masse commune** entre carte, modules et alimentation externe.
- *Contact magnétique de porte (interrupteur à lame souple)* : Dans Wokwi, simuler le contact avec un bouton poussoir.
