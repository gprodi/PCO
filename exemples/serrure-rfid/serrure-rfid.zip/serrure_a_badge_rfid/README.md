# Serrure à badge RFID

Un badge autorisé ouvre le verrou (servo) ; les autres déclenchent une alerte.

- Carte : **Arduino Uno R3 (ATmega328P)** (`arduino:avr:uno`)
- Contrôle électrique : ✅ aucun problème bloquant

## Contenu
| Fichier | Rôle |
|---|---|
| `serrure_a_badge_rfid/serrure_a_badge_rfid.ino` | programme principal (logique modifiable) |
| `serrure_a_badge_rfid/mf_components.h` | broches, objets et fonctions des composants |
| `cablage.md` / `cablage.svg` | tableau et schéma de câblage |
| `guide-montage.md` | guide pas-à-pas breadboard -> soudure -> contrôles |
| `wokwi/` | simulation : créer un projet sur wokwi.com et y coller ces fichiers |
| `kicad/projet.net` | netlist à importer dans l'éditeur de PCB KiCad |
| `nomenclature.csv` | liste du matériel |
| `platformio.ini` | compilation avec PlatformIO |

## Compiler et téléverser (arduino-cli)
```bash
arduino-cli lib install "MFRC522" "Servo"
arduino-cli compile --fqbn arduino:avr:uno serrure_a_badge_rfid
arduino-cli upload --fqbn arduino:avr:uno -p <PORT> serrure_a_badge_rfid
```

## Contrôle électrique
- **WARNING** `LEVEL_5V_INTO_3V3` — lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) fonctionne en 3,3 V mais Arduino Uno R3 (ATmega328P) pilote SDA en 5 V. → Utiliser un level shifter (ou un module avec régulateur et adaptation de niveaux).
- **WARNING** `RAIL_PEAK` — Rail 5V : pics jusqu'à ~650 mA (servo, LED, moteur) pour 400 mA disponibles. → Prévoir une alimentation externe et un condensateur 470 µF près des actionneurs.
- **INFO** `AUTO_SERIES` — Ajout automatique : 220 Ω (limite le courant de « led_ok » (broche A) à ~10 mA en 5 V).
- **INFO** `AUTO_SERIES` — Ajout automatique : 220 Ω (limite le courant de « led_ko » (broche A) à ~10 mA en 5 V).

## Niveau de vérification
- ✅ Allocation des broches et contrôle électrique (ERC) : automatiques, à chaque génération.
- ✅ Syntaxe C++ : vérifiée par les tests du dépôt (g++ avec en-têtes Arduino simulés).
- ✅ Compilation réelle (arduino-cli, cœurs AVR / ESP32 / RP2040) : job « firmware » de la CI GitHub.
- ⚠️ Pas encore monté sur du vrai matériel : teste d'abord sur breadboard (ou dans Wokwi).

## Tutoriels équivalents (pour recouper câblage et code)
- [Arduino - RFID/NFC - Servo Motor](https://arduinogetstarted.com/tutorials/arduino-rfid-nfc-servo-motor) — ArduinoGetStarted
- [Arduino RFID 'Smart Door' Tutorial](https://www.instructables.com/Arduino-RFID-Smart-Door-Tutorial) — Instructables

---
*Généré automatiquement par MicroForge (logique et textes pouvant provenir d'une IA — transparence AI Act art. 50). Vérifiez toujours le câblage avant la mise sous tension.*
