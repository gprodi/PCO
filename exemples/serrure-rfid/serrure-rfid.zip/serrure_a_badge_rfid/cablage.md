## Câblage — Serrure à badge RFID

Carte : **Arduino Uno R3 (ATmega328P)** (logique 5 V). Couleurs conseillées : rouge = 5 V, orange = 3,3 V, noir = masse, bleu = SDA, jaune = SCL, violet = SPI, vert = signal.

| # | Composant | Broche composant | Broche carte | Rôle | Fil | Remarque |
|---|---|---|---|---|---|---|
| 1 | bip (Buzzer piézo passif) | GND | GND | masse | noir |  |
| 2 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | GND | GND | masse | noir |  |
| 3 | led_ko (LED 5 mm) | C | GND | masse | noir |  |
| 4 | led_ok (LED 5 mm) | C | GND | masse | noir |  |
| 5 | verrou (Servomoteur SG90 (9 g)) | GND | GND | masse | noir |  |
| 6 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | 3.3V | 3.3V | alimentation | orange |  |
| 7 | verrou (Servomoteur SG90 (9 g)) | V+ | 5V | alimentation | rouge |  |
| 8 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | MISO | D12 | SPI MISO | violet |  |
| 9 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | MOSI | D11 | SPI MOSI | violet |  |
| 10 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | SCK | D13 | SPI horloge | violet |  |
| 11 | bip (Buzzer piézo passif) | SIG | D6 | sortie numérique | vert |  |
| 12 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | RST | D2 | sortie numérique | vert |  |
| 13 | lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) | SDA | D10 | SPI sélection (CS) | violet |  |
| 14 | led_ko (LED 5 mm) | A | D5 | sortie numérique | vert | via résistance 220 Ω en série. |
| 15 | led_ok (LED 5 mm) | A | D4 | sortie numérique | vert | via résistance 220 Ω en série. |
| 16 | verrou (Servomoteur SG90 (9 g)) | PWM | D3 | sortie PWM | vert |  |

### Composants ajoutés automatiquement

- `r_led_ok_a` : 220 Ω — limite le courant de « led_ok » (broche A) à ~10 mA en 5 V
- `r_led_ko_a` : 220 Ω — limite le courant de « led_ko » (broche A) à ~10 mA en 5 V
