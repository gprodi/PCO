# Guide de montage — Serrure à badge RFID

Un badge autorisé ouvre le verrou (servo) ; les autres déclenchent une alerte.

## 1. Outillage

- Fer à souder thermostaté (300–350 °C), panne fine conique ou biseautée
- Étain 0,8 mm avec flux (sans plomb de préférence), éponge laiton
- Tresse ou pompe à dessouder, pince coupante, pince à dénuder
- Multimètre (continuité, tension), support « troisième main »
- Lunettes de protection, pièce aérée (fumées de flux)

## 2. Sécurité

- Toujours débrancher l'USB et les piles avant de souder ou de recâbler.
- Le fer chauffe à plus de 300 °C : le reposer sur son support, jamais sur la table.
- Se laver les mains après la soudure (étain/flux).

## 3. Points d'attention électriques (à lire avant de câbler)

- **⚠️ Attention** — lecteur (Lecteur RFID RC522 13,56 MHz (SPI) + badges) fonctionne en 3,3 V mais Arduino Uno R3 (ATmega328P) pilote SDA en 5 V. *Correctif :* Utiliser un level shifter (ou un module avec régulateur et adaptation de niveaux).
- **⚠️ Attention** — Rail 5V : pics jusqu'à ~650 mA (servo, LED, moteur) pour 400 mA disponibles. *Correctif :* Prévoir une alimentation externe et un condensateur 470 µF près des actionneurs.

## 4. Étape 1 — Prototype sur breadboard (sans soudure)

1. Placer la carte à cheval sur la rainure centrale de la breadboard.
2. Relier les rails : **3_3V**, **5V** et **GND** (fil noir) aux lignes d'alimentation de la plaque.
3. Câbler en suivant le **tableau de câblage** (`cablage.md`) ligne par ligne, dans l'ordre : masse, alimentations, bus, signaux.
4. Insérer les résistances ajoutées automatiquement :
   - `r_led_ok_a` 220 Ω — limite le courant de « led_ok » (broche A) à ~10 mA en 5 V
   - `r_led_ko_a` 220 Ω — limite le courant de « led_ko » (broche A) à ~10 mA en 5 V
5. Téléverser le firmware et valider le fonctionnement (moniteur série 115200 bauds) **avant** de souder quoi que ce soit.

## 5. Étape 2 — Montage définitif sur plaque à pastilles

1. Souder des **barrettes femelles** pour la carte (elle reste amovible) et des barrettes mâles/femelles pour chaque module.
2. Tracer les **rails d'alimentation** au fil rigide (rouge/orange) et la **masse** (noir) le long de la plaque.
3. Souder les **bus partagés** (I2C/SPI) en étoile depuis la carte.
4. Souder les **signaux** un par un en cochant le tableau de câblage.
5. Souder les **résistances** au plus près de la broche protégée.

### Geste de soudure

1. Chauffer **en même temps** la pastille et la patte (1–2 s).
2. Apporter l'étain sur la jonction (pas sur la panne).
3. Retirer l'étain puis le fer ; ne pas bouger pendant 2 s.
4. Contrôler : soudure brillante en forme de petit volcan, aucun pont avec la pastille voisine.

## 6. Contrôles au multimètre AVANT la mise sous tension

Mode continuité (bip). Chaque ligne doit biper entre toutes ses broches :

- [ ] **3_3V** : board.3.3V, lecteur.3.3V
- [ ] **5V** : board.5V, verrou.V+
- [ ] **GND** : board.GND, lecteur.GND, verrou.GND, led_ok.C, led_ko.C, bip.GND
- [ ] **SPI_MISO** : board.D12, lecteur.MISO
- [ ] **SPI_MOSI** : board.D11, lecteur.MOSI
- [ ] **SPI_SCK** : board.D13, lecteur.SCK
- [ ] **BIP_SIG** : board.D6, bip.SIG
- [ ] **LECTEUR_CS** : board.D10, lecteur.SDA
- [ ] **LECTEUR_RST** : board.D2, lecteur.RST
- [ ] **LED_KO_A** : board.D5, r_led_ko_a.1
- [ ] **LED_KO_A_R** : r_led_ko_a.2, led_ko.A
- [ ] **LED_OK_A** : board.D4, r_led_ok_a.1
- [ ] **LED_OK_A_R** : r_led_ok_a.2, led_ok.A
- [ ] **VERROU_PWM** : board.D3, verrou.PWM

Puis, en mode ohmmètre, **aucun court-circuit** :
- [ ] entre **3_3V** et **GND** : résistance > 1 kΩ
- [ ] entre **5V** et **GND** : résistance > 1 kΩ

## 7. Première mise sous tension

1. Brancher l'USB seul (pas de piles) ; toucher les composants après 10 s : rien ne doit chauffer.
2. Téléverser `le sketch` (carte **Arduino Uno R3 (ATmega328P)**, FQBN `arduino:avr:uno`).
3. Ouvrir le moniteur série (115200 bauds) et vérifier les messages d'initialisation.

## 8. Dépannage

- **rc522-rfid** : Aucun badge lu : alimentation 3,3 V (jamais 5 V), câblage SPI complet.
- **sg90-servo** : Tremblements/reset de la carte : alimentation insuffisante, ajouter 5 V externe + 470 µF.
- Rien ne marche : vérifier la **masse commune** entre carte, modules et alimentation externe.
- *Lecteur RFID RC522 13,56 MHz (SPI) + badges* : Sur une carte 5 V (Uno), les lignes SPI devraient passer par un level shifter (le RC522 n'est pas officiellement tolérant 5 V).
- *Servomoteur SG90 (9 g)* : Pic de 650 mA au démarrage : au-delà d'un servo, prévoir une alimentation 5 V externe (masses reliées).
