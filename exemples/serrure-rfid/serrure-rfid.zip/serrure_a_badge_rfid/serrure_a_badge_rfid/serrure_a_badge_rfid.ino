// Serrure à badge RFID — généré par MicroForge
// Un badge autorisé ouvre le verrou (servo) ; les autres déclenchent une alerte.
// Carte : Arduino Uno R3 (ATmega328P)
#include "mf_components.h"

const String BADGE_AUTORISE = "DE AD BE EF";  // remplacer par l'UID lu dans le moniteur série

void setup() {
  Serial.begin(115200);
  mf_setup_components();

  verrou_angle(0);
}

void loop() {
  String uid = lecteur_read_uid();
  if (uid.length() > 0) {
    Serial.println("Badge : " + uid);
    if (uid == BADGE_AUTORISE) {
      led_ok_on(); bip_beep(2000, 100);
      verrou_angle(90); delay(3000); verrou_angle(0);
      led_ok_off();
    } else {
      led_ko_on(); bip_beep(300, 500);
      delay(1000);
      led_ko_off();
    }
  }
}
