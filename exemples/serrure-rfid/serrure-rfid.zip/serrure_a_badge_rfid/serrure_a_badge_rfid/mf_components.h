// mf_components.h — généré par MicroForge pour « Serrure à badge RFID »
// Carte : Arduino Uno R3 (ATmega328P) — FQBN arduino:avr:uno
// Ne modifiez pas ce fichier à la main : régénérez-le depuis MicroForge.
// À inclure UNIQUEMENT depuis le .ino (les fonctions y sont définies).
#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Servo.h>

#if defined(ESP32)
  #define MF_ADC_MAX 4095
#else
  #define MF_ADC_MAX 1023
#endif

// ---- Broches (cf. tableau de câblage) ----
const uint8_t BUS_SPI_SCK = 13;  // D13 (bus partagé)
const uint8_t BUS_SPI_MOSI = 11;  // D11 (bus partagé)
const uint8_t BUS_SPI_MISO = 12;  // D12 (bus partagé)
const uint8_t PIN_LECTEUR_SDA = 10;  // D10 -> lecteur.SDA
const uint8_t PIN_LECTEUR_RST = 2;  // D2 -> lecteur.RST
const uint8_t PIN_VERROU_PWM = 3;  // D3 -> verrou.PWM
const uint8_t PIN_LED_OK_A = 4;  // D4 -> led_ok.A
const uint8_t PIN_LED_KO_A = 5;  // D5 -> led_ko.A
const uint8_t PIN_BIP_SIG = 6;  // D6 -> bip.SIG

// ---- Objets des composants ----
// --- lecteur : Lecteur RFID RC522 13,56 MHz (SPI) + badges
MFRC522 lecteur_dev(PIN_LECTEUR_SDA, PIN_LECTEUR_RST);
// --- verrou : Servomoteur SG90 (9 g)
Servo verrou_dev;

// ---- Fonctions des composants (utilisables dans loop()) ----
// --- lecteur : Lecteur RFID RC522 13,56 MHz (SPI) + badges
// UID du badge présenté (ex. "DE AD BE EF") ou "" si aucun.
String lecteur_read_uid() {
  if (!lecteur_dev.PICC_IsNewCardPresent() || !lecteur_dev.PICC_ReadCardSerial()) { return ""; }
  String uid = "";
  for (byte i = 0; i < lecteur_dev.uid.size; i++) {
    if (lecteur_dev.uid.uidByte[i] < 0x10) { uid += "0"; }
    uid += String(lecteur_dev.uid.uidByte[i], HEX);
    if (i + 1 < lecteur_dev.uid.size) { uid += " "; }
  }
  lecteur_dev.PICC_HaltA();
  uid.toUpperCase();
  return uid;
}
// --- verrou : Servomoteur SG90 (9 g)
void verrou_angle(int deg) { verrou_dev.write(constrain(deg, 0, 180)); }
// --- led_ok : LED 5 mm
void led_ok_on() { digitalWrite(PIN_LED_OK_A, HIGH); }
void led_ok_off() { digitalWrite(PIN_LED_OK_A, LOW); }
void led_ok_set(bool on) { digitalWrite(PIN_LED_OK_A, on ? HIGH : LOW); }
void led_ok_toggle() { digitalWrite(PIN_LED_OK_A, !digitalRead(PIN_LED_OK_A)); }
// --- led_ko : LED 5 mm
void led_ko_on() { digitalWrite(PIN_LED_KO_A, HIGH); }
void led_ko_off() { digitalWrite(PIN_LED_KO_A, LOW); }
void led_ko_set(bool on) { digitalWrite(PIN_LED_KO_A, on ? HIGH : LOW); }
void led_ko_toggle() { digitalWrite(PIN_LED_KO_A, !digitalRead(PIN_LED_KO_A)); }
// --- bip : Buzzer piézo passif
void bip_beep(unsigned int freq, unsigned long ms) { tone(PIN_BIP_SIG, freq, ms); }
void bip_stop() { noTone(PIN_BIP_SIG); }

// ---- Initialisation de tous les composants ----
inline void mf_setup_components() {
  SPI.begin();
  // lecteur
  lecteur_dev.PCD_Init();
  // verrou
  verrou_dev.attach(PIN_VERROU_PWM);
  // led_ok
  pinMode(PIN_LED_OK_A, OUTPUT);
  // led_ko
  pinMode(PIN_LED_KO_A, OUTPUT);
  // bip
  pinMode(PIN_BIP_SIG, OUTPUT);
}
