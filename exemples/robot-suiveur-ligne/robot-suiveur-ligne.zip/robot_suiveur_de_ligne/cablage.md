## Câblage — Robot suiveur de ligne

Carte : **Arduino Uno R3 (ATmega328P)** (logique 5 V). Couleurs conseillées : rouge = 5 V, orange = 3,3 V, noir = masse, bleu = SDA, jaune = SCL, violet = SPI, vert = signal.

| # | Composant | Broche composant | Broche carte | Rôle | Fil | Remarque |
|---|---|---|---|---|---|---|
| 1 | droite (Capteur de ligne infrarouge TCRT5000) | GND | GND | masse | noir |  |
| 2 | gauche (Capteur de ligne infrarouge TCRT5000) | GND | GND | masse | noir |  |
| 3 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | GND | GND | masse | noir |  |
| 4 | droite (Capteur de ligne infrarouge TCRT5000) | VCC | 5V | alimentation | rouge |  |
| 5 | gauche (Capteur de ligne infrarouge TCRT5000) | VCC | 5V | alimentation | rouge |  |
| 6 | droite (Capteur de ligne infrarouge TCRT5000) | DO | D3 | entrée numérique | vert |  |
| 7 | gauche (Capteur de ligne infrarouge TCRT5000) | DO | D2 | entrée numérique | vert |  |
| 8 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | ENA | D5 | sortie PWM | vert |  |
| 9 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | ENB | D9 | sortie PWM | vert |  |
| 10 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | IN1 | D4 | sortie numérique | vert |  |
| 11 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | IN2 | D6 | sortie numérique | vert |  |
| 12 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | IN3 | D7 | sortie numérique | vert |  |
| 13 | moteurs (Pont en H L298N (pilote de 2 moteurs CC)) | IN4 | D8 | sortie numérique | vert |  |
