# Guide de montage — Robot suiveur de ligne

Deux capteurs infrarouges sous le châssis, et le robot suit une piste tracée au ruban noir.

## 1. Outillage

- Fer à souder thermostaté (300–350 °C), panne fine conique ou biseautée
- Étain 0,8 mm avec flux (sans plomb de préférence), éponge laiton
- Tresse ou pompe à dessouder, pince coupante, pince à dénuder
- Multimètre (continuité, tension), support « troisième main »
- Lunettes de protection, pièce aérée (fumées de flux)

## 2. Sécurité

- Toujours débrancher l'USB et les piles avant de souder ou de recâbler.
- Le fer chauffe à plus de 300 °C : le reposer sur son support, jamais sur la table.
- Se laver les mains après la soudure (étain/flux).

## 4. Étape 1 — Prototype sur breadboard (sans soudure)

1. Placer la carte à cheval sur la rainure centrale de la breadboard.
2. Relier les rails : **5V** et **GND** (fil noir) aux lignes d'alimentation de la plaque.
3. Câbler en suivant le **tableau de câblage** (`cablage.md`) ligne par ligne, dans l'ordre : masse, alimentations, bus, signaux.
4. Téléverser le firmware et valider le fonctionnement (moniteur série 115200 bauds) **avant** de souder quoi que ce soit.

## 5. Étape 2 — Montage définitif sur plaque à pastilles

1. Souder des **barrettes femelles** pour la carte (elle reste amovible) et des barrettes mâles/femelles pour chaque module.
2. Tracer les **rails d'alimentation** au fil rigide (rouge/orange) et la **masse** (noir) le long de la plaque.
3. Souder les **bus partagés** (I2C/SPI) en étoile depuis la carte.
4. Souder les **signaux** un par un en cochant le tableau de câblage.
5. Souder les **résistances** au plus près de la broche protégée.

### Geste de soudure

1. Chauffer **en même temps** la pastille et la patte (1–2 s).
2. Apporter l'étain sur la jonction (pas sur la panne).
3. Retirer l'étain puis le fer ; ne pas bouger pendant 2 s.
4. Contrôler : soudure brillante en forme de petit volcan, aucun pont avec la pastille voisine.

## 6. Contrôles au multimètre AVANT la mise sous tension

Mode continuité (bip). Chaque ligne doit biper entre toutes ses broches :

- [ ] **5V** : board.5V, gauche.VCC, droite.VCC
- [ ] **GND** : board.GND, gauche.GND, droite.GND, moteurs.GND
- [ ] **DROITE_DO** : board.D3, droite.DO
- [ ] **GAUCHE_DO** : board.D2, gauche.DO
- [ ] **MOTEURS_ENA** : board.D5, moteurs.ENA
- [ ] **MOTEURS_ENB** : board.D9, moteurs.ENB
- [ ] **MOTEURS_IN1** : board.D4, moteurs.IN1
- [ ] **MOTEURS_IN2** : board.D6, moteurs.IN2
- [ ] **MOTEURS_IN3** : board.D7, moteurs.IN3
- [ ] **MOTEURS_IN4** : board.D8, moteurs.IN4

Puis, en mode ohmmètre, **aucun court-circuit** :
- [ ] entre **5V** et **GND** : résistance > 1 kΩ

## 7. Première mise sous tension

1. Brancher l'USB seul (pas de piles) ; toucher les composants après 10 s : rien ne doit chauffer.
2. Téléverser `le sketch` (carte **Arduino Uno R3 (ATmega328P)**, FQBN `arduino:avr:uno`).
3. Ouvrir le moniteur série (115200 bauds) et vérifier les messages d'initialisation.

## 8. Dépannage

- Vérifier masse commune et alimentation.
- Rien ne marche : vérifier la **masse commune** entre carte, modules et alimentation externe.
- *Pont en H L298N (pilote de 2 moteurs CC)* : Alimenter les moteurs par la borne 12V (batterie 7–12 V) ; relier la masse de la batterie à celle de la carte.
- *Pont en H L298N (pilote de 2 moteurs CC)* : Chute de tension ~2 V dans le L298N : un TB6612FNG est plus efficace.
- *Moteur jaune TT 3–6 V avec réducteur (+ roue)* : Se branche sur OUT1/OUT2 (ou OUT3/OUT4) du L298N, jamais directement sur la carte.
- *Moteur jaune TT 3–6 V avec réducteur (+ roue)* : Se branche sur OUT1/OUT2 (ou OUT3/OUT4) du L298N, jamais directement sur la carte.
