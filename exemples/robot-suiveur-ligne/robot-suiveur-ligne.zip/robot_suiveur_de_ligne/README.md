# Robot suiveur de ligne

Deux capteurs infrarouges sous le châssis, et le robot suit une piste tracée au ruban noir.

- Carte : **Arduino Uno R3 (ATmega328P)** (`arduino:avr:uno`)
- Contrôle électrique : ✅ aucun problème bloquant

## Contenu
| Fichier | Rôle |
|---|---|
| `robot_suiveur_de_ligne/robot_suiveur_de_ligne.ino` | programme principal (logique modifiable) |
| `robot_suiveur_de_ligne/mf_components.h` | broches, objets et fonctions des composants |
| `cablage.md` / `cablage.svg` | tableau et schéma de câblage |
| `guide-montage.md` | guide pas-à-pas breadboard -> soudure -> contrôles |
| `wokwi/` | simulation : créer un projet sur wokwi.com et y coller ces fichiers |
| `kicad/projet.net` | netlist à importer dans l'éditeur de PCB KiCad |
| `nomenclature.csv` | liste du matériel |
| `platformio.ini` | compilation avec PlatformIO |

## Compiler et téléverser (arduino-cli)
```bash
arduino-cli lib install 
arduino-cli compile --fqbn arduino:avr:uno robot_suiveur_de_ligne
arduino-cli upload --fqbn arduino:avr:uno -p <PORT> robot_suiveur_de_ligne
```

## Contrôle électrique
- aucun

## Niveau de vérification
- ✅ Allocation des broches et contrôle électrique (ERC) : automatiques, à chaque génération.
- ✅ Syntaxe C++ : vérifiée par les tests du dépôt (g++ avec en-têtes Arduino simulés).
- ✅ Compilation réelle (arduino-cli, cœurs AVR / ESP32 / RP2040) : job « firmware » de la CI GitHub.
- ⚠️ Pas encore monté sur du vrai matériel : teste d'abord sur breadboard (ou dans Wokwi).

## Tutoriels équivalents (pour recouper câblage et code)
- [Line Follower Robot using Arduino](https://www.hackster.io/webotricks/line-follower-robot-using-arduino-1ee882) — Hackster
- [How To Build A Line Follower Robot With Arduino](https://www.electromaker.io/project/view/how-to-build-a-line-follower-robot-with-arduino) — Electromaker

---
*Généré automatiquement par MicroForge (logique et textes pouvant provenir d'une IA — transparence AI Act art. 50). Vérifiez toujours le câblage avant la mise sous tension.*
