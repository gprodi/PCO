// Robot suiveur de ligne — généré par MicroForge
// Deux capteurs infrarouges sous le châssis, et le robot suit une piste tracée au ruban noir.
// Carte : Arduino Uno R3 (ATmega328P)
#include "mf_components.h"

void setup() {
  Serial.begin(115200);
  mf_setup_components();

}

void loop() {
  bool g = gauche_on_line();
  bool d = droite_on_line();
  if (!g && !d) { moteurs_motors(170, 170); }        // la ligne est entre les capteurs : tout droit
  else if (g && !d) { moteurs_motors(40, 190); }     // la ligne part à gauche
  else if (!g && d) { moteurs_motors(190, 40); }     // la ligne part à droite
  else { moteurs_stop(); }                           // intersection ou fin de piste
  delay(5);
}
