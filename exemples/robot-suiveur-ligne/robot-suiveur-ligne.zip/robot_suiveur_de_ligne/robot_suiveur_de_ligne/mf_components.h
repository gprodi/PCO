// mf_components.h — généré par MicroForge pour « Robot suiveur de ligne »
// Carte : Arduino Uno R3 (ATmega328P) — FQBN arduino:avr:uno
// Ne modifiez pas ce fichier à la main : régénérez-le depuis MicroForge.
// À inclure UNIQUEMENT depuis le .ino (les fonctions y sont définies).
#pragma once
#include <Arduino.h>

#if defined(ESP32)
  #define MF_ADC_MAX 4095
#else
  #define MF_ADC_MAX 1023
#endif

// ---- Broches (cf. tableau de câblage) ----
const uint8_t PIN_GAUCHE_DO = 2;  // D2 -> gauche.DO
const uint8_t PIN_DROITE_DO = 3;  // D3 -> droite.DO
const uint8_t PIN_MOTEURS_ENA = 5;  // D5 -> moteurs.ENA
const uint8_t PIN_MOTEURS_IN1 = 4;  // D4 -> moteurs.IN1
const uint8_t PIN_MOTEURS_IN2 = 6;  // D6 -> moteurs.IN2
const uint8_t PIN_MOTEURS_IN3 = 7;  // D7 -> moteurs.IN3
const uint8_t PIN_MOTEURS_IN4 = 8;  // D8 -> moteurs.IN4
const uint8_t PIN_MOTEURS_ENB = 9;  // D9 -> moteurs.ENB

// ---- Objets des composants ----

// ---- Fonctions des composants (utilisables dans loop()) ----
// --- gauche : Capteur de ligne infrarouge TCRT5000
// Vrai au-dessus de la ligne noire (peu de réflexion infrarouge).
bool gauche_on_line() { return digitalRead(PIN_GAUCHE_DO) == HIGH; }
// --- droite : Capteur de ligne infrarouge TCRT5000
// Vrai au-dessus de la ligne noire (peu de réflexion infrarouge).
bool droite_on_line() { return digitalRead(PIN_DROITE_DO) == HIGH; }
// --- moteurs : Pont en H L298N (pilote de 2 moteurs CC)
// vitesse de -255 (arrière) à 255 (avant) pour chaque moteur.
void moteurs_motors(int gauche, int droite) {
  digitalWrite(PIN_MOTEURS_IN1, gauche >= 0 ? HIGH : LOW); digitalWrite(PIN_MOTEURS_IN2, gauche >= 0 ? LOW : HIGH);
  digitalWrite(PIN_MOTEURS_IN3, droite >= 0 ? HIGH : LOW); digitalWrite(PIN_MOTEURS_IN4, droite >= 0 ? LOW : HIGH);
  analogWrite(PIN_MOTEURS_ENA, constrain(abs(gauche), 0, 255)); analogWrite(PIN_MOTEURS_ENB, constrain(abs(droite), 0, 255));
}
void moteurs_stop() { moteurs_motors(0, 0); }

// ---- Initialisation de tous les composants ----
inline void mf_setup_components() {
  // gauche
  pinMode(PIN_GAUCHE_DO, INPUT);
  // droite
  pinMode(PIN_DROITE_DO, INPUT);
  // moteurs
  pinMode(PIN_MOTEURS_ENA, OUTPUT); pinMode(PIN_MOTEURS_IN1, OUTPUT); pinMode(PIN_MOTEURS_IN2, OUTPUT);
  pinMode(PIN_MOTEURS_ENB, OUTPUT); pinMode(PIN_MOTEURS_IN3, OUTPUT); pinMode(PIN_MOTEURS_IN4, OUTPUT);
}
